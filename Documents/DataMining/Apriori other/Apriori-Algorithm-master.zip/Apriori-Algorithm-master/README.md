Apriori-Algorithm
=================

Apriori is a classic algorithm for learning association rules.
Apriori is designed to operate on databases containing transactions (for example, collections of items bought by customers, or details of a website frequentation).


for more info visit:
http://www.codeproject.com/Articles/70371/Apriori-Algorithm