﻿using System;
using AprioriAlgorithm;

namespace WPFClient
{
    public interface IResult
    {
        void Show(Output output);
    }
}