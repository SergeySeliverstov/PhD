﻿using System.Collections.Generic;
namespace AprioriAlgorithm
{
    interface ISorter
    {
        string Sort(string token);
    }
}
